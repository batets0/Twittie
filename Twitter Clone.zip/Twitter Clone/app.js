// app.js
// app.js

import { auth, db } from './firebase-config.js';
import { createUserWithEmailAndPassword, signInWithEmailAndPassword, signOut } from 'firebase/auth';
import { collection, addDoc, query, orderBy, limit, onSnapshot } from 'firebase/firestore';

document.addEventListener('DOMContentLoaded', function() {
    // ... (previous code remains)

    // Authentication
    const signUpForm = document.getElementById('signUpForm');
    const loginForm = document.getElementById('loginForm');
    const logoutButton = document.getElementById('logoutButton');

    if (signUpForm) {
        signUpForm.addEventListener('submit', (e) => {
            e.preventDefault();
            const email = signUpForm.email.value;
            const password = signUpForm.password.value;
            createUserWithEmailAndPassword(auth, email, password)
                .then((userCredential) => {
                    console.log('User signed up:', userCredential.user);
                })
                .catch((error) => {
                    console.error('Error signing up:', error);
                });
        });
    }

    if (loginForm) {
        loginForm.addEventListener('submit', (e) => {
            e.preventDefault();
            const email = loginForm.email.value;
            const password = loginForm.password.value;
            signInWithEmailAndPassword(auth, email, password)
                .then((userCredential) => {
                    console.log('User logged in:', userCredential.user);
                })
                .catch((error) => {
                    console.error('Error logging in:', error);
                });
        });
    }

    if (logoutButton) {
        logoutButton.addEventListener('click', () => {
            signOut(auth).then(() => {
                console.log('User signed out');
            }).catch((error) => {
                console.error('Error signing out:', error);
            });
        });
    }

    // Tweet posting (now connected to Firebase)
    if (tweetButton) {
        tweetButton.addEventListener('click', function() {
            if (tweetTextArea.value.trim() !== '') {
                const user = auth.currentUser;
                if (user) {
                    addDoc(collection(db, 'tweets'), {
                        content: tweetTextArea.value,
                        userId: user.uid,
                        createdAt: new Date()
                    }).then(() => {
                        console.log('Tweet posted successfully');
                        tweetTextArea.value = '';
                        textLimit.textContent = '100%';
                    }).catch((error) => {
                        console.error('Error posting tweet:', error);
                    });
                } else {
                    alert('Please log in to post a tweet');
                }
            }
        });
    }

    // Load tweets from Firebase
    const tweetsContainer = document.querySelector('.post_main_bx');
    if (tweetsContainer) {
        const q = query(collection(db, 'tweets'), orderBy('createdAt', 'desc'), limit(20));
        onSnapshot(q, (snapshot) => {
            tweetsContainer.innerHTML = ''; // Clear existing tweets
            snapshot.forEach((doc) => {
                const tweet = doc.data();
                const tweetElement = createTweetElement(tweet);
                tweetsContainer.appendChild(tweetElement);
            });
        });
    }
});

function createTweetElement(tweet) {
    // Create and return a DOM element for a tweet
    const div = document.createElement('div');
    div.className = 'post_card_bx';
    div.innerHTML = `
        <div class="post_profile">
            <img src="img/user_placeholder.jpg" alt="">
        </div>
        <div class="content">
            <div class="user_name_time">
                <h5>User <p>@user${tweet.userId.substring(0, 5)}</p></h5>
                <h6><i class="fa-regular fa-clock"></i> ${new Date(tweet.createdAt.toDate()).toLocaleString()}</h6>
            </div>
            <h3>${tweet.content}</h3>
            <div class="tweet_card_social_data">
                <div class="tweet_social_card">
                    <i class="fa-solid fa-comment"></i>
                    <span>0</span>
                </div>
                <div class="tweet_social_card">
                    <i class="fa-solid fa-repeat"></i>
                    <span>0</span>
                </div>
                <div class="tweet_social_card">
                    <i class="fa-solid fa-heart"></i>
                    <span>0</span>
                </div>
                <div class="tweet_social_card">
                    <i class="fa-solid fa-share"></i>
                </div>
            </div>
        </div>
    `;
    return div;
}

// ... (rest of the previous code)

document.addEventListener('DOMContentLoaded', function() {
    // Tweet character limit
    const tweetTextArea = document.getElementById('tweet_text_area');
    const textLimit = document.getElementById('text_limit');
    const tweetButton = document.getElementById('tweet_post');

    if (tweetTextArea && textLimit && tweetButton) {
        tweetTextArea.addEventListener('input', function() {
            const remainingChars = 200 - this.value.length;
            const percentage = (remainingChars / 200) * 100;
            textLimit.textContent = `${Math.round(percentage)}%`;
            
            if (remainingChars < 0) {
                textLimit.style.color = 'red';
                tweetButton.disabled = true;
            } else {
                textLimit.style.color = '';
                tweetButton.disabled = false;
            }
        });
    }

    // Audience selection
    const audienceBtn = document.getElementById('audience_btn');
    const audienceOptions = document.querySelector('.show_bx_1');

    if (audienceBtn && audienceOptions) {
        audienceBtn.addEventListener('click', function() {
            audienceOptions.style.display = audienceOptions.style.display === 'none' ? 'block' : 'none';
        });

        const audienceChoices = audienceOptions.querySelectorAll('.check_audience');
        audienceChoices.forEach(choice => {
            choice.addEventListener('click', function() {
                audienceBtn.textContent = this.querySelector('h6').textContent + ' ▼';
                audienceOptions.style.display = 'none';
            });
        });
    }

    // Who can reply selection
    const replyBtn = document.querySelector('.select_reply_btn');
    const replyOptions = document.querySelector('.who_can_reply_bx');

    if (replyBtn && replyOptions) {
        replyBtn.addEventListener('click', function() {
            replyOptions.style.display = replyOptions.style.display === 'none' ? 'block' : 'none';
        });

        const replyChoices = replyOptions.querySelectorAll('.who_can_reply');
        replyChoices.forEach(choice => {
            choice.addEventListener('click', function() {
                replyBtn.innerHTML = `<i class="fas fa-globe-asia"></i> ${this.querySelector('h6').textContent}`;
                replyOptions.style.display = 'none';
            });
        });
    }

    // Tweet posting (simulated)
    if (tweetButton) {
        tweetButton.addEventListener('click', function() {
            if (tweetTextArea.value.trim() !== '') {
                alert('Tweet posted! (This is a simulation)');
                tweetTextArea.value = '';
                textLimit.textContent = '100%';
            }
        });
    }

    // Like, Retweet, and Comment functionality (simulated)
    const socialActions = document.querySelectorAll('.tweet_social_card');
    socialActions.forEach(action => {
        action.addEventListener('click', function() {
            const icon = this.querySelector('i');
            const count = this.querySelector('span');
            
            if (icon.classList.contains('fa-heart')) {
                icon.style.color = icon.style.color === 'red' ? '' : 'red';
                count.textContent = icon.style.color === 'red' ? 
                    parseInt(count.textContent) + 1 : 
                    parseInt(count.textContent) - 1;
            } else if (icon.classList.contains('fa-repeat')) {
                alert('Retweeted! (This is a simulation)');
            } else if (icon.classList.contains('fa-comment')) {
                alert('Comment feature not implemented in this demo.');
            }
        });
    });
});

// Function to auto-grow textarea
function auto_grow(element) {
    element.style.height = "5px";
    element.style.height = (element.scrollHeight)+"px";
}

