// firebase-config.js

import { initializeApp } from 'firebase/app';
import { getAuth } from 'firebase/auth';
import { getFirestore } from 'firebase/firestore';

const firebaseConfig = {
  // Your Firebase configuration object goes here
  apiKey: "AIzaSyB7e-tThhCg-pU5z-l8u5dEnn1W_aFVFOQ",
  authDomain: "twittie-51746.firebaseapp.com",
  projectId: "twittie-51746",
  storageBucket: "twittie-51746.appspot.com",
  messagingSenderId: "939546279895",
  appId: "1:939546279895:web:84074105cda9d295001592"
};

const app = initializeApp(firebaseConfig);
const auth = getAuth(app);
const db = getFirestore(app);

export { auth, db };